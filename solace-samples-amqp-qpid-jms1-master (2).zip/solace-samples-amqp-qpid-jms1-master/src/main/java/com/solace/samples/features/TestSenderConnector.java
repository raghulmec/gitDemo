package com.solace.samples.features;

import com.solace.samples.QueueProducer;

public class TestSenderConnector 
{

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		QueueProducer qc = new QueueProducer();
		String s[]={};
		QueueProducer.main(s);
	}

}
